var smallImages = document.getElementsByClassName('small-image');
var bigImage = document.getElementById('big_image');

for (var i = 0; i < smallImages.length; i++) {
  smallImages[i].addEventListener('click', function (event) {
    bigImage.src = event.target.src;
  })
}